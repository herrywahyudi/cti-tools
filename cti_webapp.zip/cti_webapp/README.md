# CTI Seafarer Tools

Internal web app for CTI Indonesia — Bali Office.

## Tools

### 1. Seafarer Document Lookup
Fills the **Documents Processed by Seafarer** column in the Processing file by matching against all registration logs (STCW, Vaccine, Passport, Seaman's Book, Medical, ATV/MCV, Visa).

### 2. Service Agreement Auto Fill
Generates filled PDF service agreements for each seafarer based on their processed documents.

## How to Deploy (One Time Setup)

1. Push this repo to GitHub
2. Go to [streamlit.io/cloud](https://streamlit.io/cloud) and sign in with GitHub
3. Click **New app** → select this repo → set `app.py` as the main file
4. Click **Deploy**
5. Share the link with your team

## How to Use

1. Open the app link in any browser
2. **Tab 1 — Seafarer Lookup:**
   - Upload `Processing.xlsx`
   - Upload all 7 lookup files
   - Click Run → Download updated Excel
3. **Tab 2 — Service Agreement:**
   - Upload the updated Excel from Step 1
   - Upload the PDF template
   - Click Run → Download ZIP of filled PDFs

## Requirements (auto-installed by Streamlit Cloud)
See `requirements.txt`
